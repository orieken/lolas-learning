export { plugin } from './Game';
